use TLily::Version;

BEGIN {    
    $TLily::Version::VERSION .= "-aqua";
}

require "tlily.PL";