//
//  main.m
//  Tigerlily
//
//  Created by Will Coleda on Wed Jul 23 2003.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CamelBones/CamelBones.h>

int main(int argc, const char *argv[])
{
    return CBApplicationMain(argc, argv);
}
