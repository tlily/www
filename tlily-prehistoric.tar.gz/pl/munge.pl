#!/usr/bin/perl -w

while (<>) {
    print $_;
    last if (/^PART2/);
}

@stack = ();
while (<>) {
    @els = split / /;
    if ($els[0] eq '+') {
	unshift @stack, $els[4];
    } else {
	while (($s = shift @stack) ne $els[4]) {
	    print "- $els[1] $els[2] $els[3] $s";
	}
    }
    print $_;
}

foreach (@stack) {
    print "- $els[1] $els[2] $els[3] $_";
}
